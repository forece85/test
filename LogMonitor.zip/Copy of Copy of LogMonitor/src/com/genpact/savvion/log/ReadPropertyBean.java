package com.genpact.savvion.log;

import java.util.ArrayList;

public class ReadPropertyBean
{
  private static String DaemonPort;
  private static String SleepTime;
  private static String appCode;
  private static String fileMonitor;
  private static ArrayList<String> files;
  private static ArrayList<String> fileNames;
  private static ArrayList<String> fileFrequency;
  private static String mailServer;
  private static String mailUser;
  private static String mailPass;
  private static String toEmailIDs;
  private static String CCEmailIDs;
  private static String fromEmailid;
  private static ArrayList<String> DateStamp;
  private static ArrayList<String> indStr;
  private static ArrayList<String> indLst;
  
  public static void setDaemonPort(String daemonPort)
  {
    DaemonPort = daemonPort;
  }

  public static String getDaemonPort()
  {
    return DaemonPort;
  }

  public static void setSleepTime(String sleepTime)
  {
    SleepTime = sleepTime;
  }

  public static String getSleepTime()
  {
    return SleepTime;
  }

  public static void setAppCode(String appCode)
  {
    ReadPropertyBean.appCode = appCode;
  }

  public static String getAppCode()
  {
    return appCode;
  }

  public static void setFileMonitor(String fileMonitor)
  {
    ReadPropertyBean.fileMonitor = fileMonitor;
  }

  public static String getFileMonitor()
  {
    return fileMonitor;
  }

  public static void setFiles(ArrayList<String> fs)
  {
    files = fs;
  }

  public static ArrayList<String> getFiles()
  {
    return files;
  }

  public static void setFileNames(ArrayList<String> fileNames)
  {
    ReadPropertyBean.fileNames = fileNames;
  }

  public static ArrayList<String> getFileNames()
  {
    return fileNames;
  }

  public static void setFileFrequency(ArrayList<String> fileFrequency)
  {
    ReadPropertyBean.fileFrequency = fileFrequency;
  }

  public static ArrayList<String> getFileFrequency()
  {
    return fileFrequency;
  }

  public static void setMailServer(String mailServer)
  {
    ReadPropertyBean.mailServer = mailServer;
  }

  public static String getMailServer()
  {
    return mailServer;
  }

  public static void setMailUser(String mailUser)
  {
    ReadPropertyBean.mailUser = mailUser;
  }

  public static String getMailUser()
  {
    return mailUser;
  }

  public static void setMailPass(String mailPass)
  {
    ReadPropertyBean.mailPass = mailPass;
  }

  public static String getMailPass()
  {
    return mailPass;
  }

  public static void setToEmailIDs(String toEmailIDs)
  {
    ReadPropertyBean.toEmailIDs = toEmailIDs;
  }

  public static String getToEmailIDs()
  {
    return toEmailIDs;
  }

  public static void setCCEmailIDs(String cCEmailIDs)
  {
    CCEmailIDs = cCEmailIDs;
  }

  public static String getCCEmailIDs()
  {
    return CCEmailIDs;
  }

  public static void setFromEmailid(String fromEmailid)
  {
    ReadPropertyBean.fromEmailid = fromEmailid;
  }

  public static String getFromEmailid()
  {
    return fromEmailid;
  }
	public static void setDateStamp(ArrayList<String> DateStamp)
	{
	  ReadPropertyBean.DateStamp = DateStamp;
	}

	public static ArrayList<String> getDateStamp()
	{
	  return DateStamp;
	}
	
	public static void setindStr(ArrayList<String> indStr)
	{
	  ReadPropertyBean.indStr = indStr;
	}
	
	public static ArrayList<String> getindStr()
	{
	  return indStr;
	}
	
	public static void setindLst(ArrayList<String> indLst)
	{
	  ReadPropertyBean.indLst = indLst;
	}
	
	public static ArrayList<String> getindLst()
	{
	  return indLst;
	}
}