 package com.genpact.savvion.log;
 import java.util.Date;
 import java.util.Properties;
 import javax.mail.Authenticator;
 import javax.mail.Message;
 import javax.mail.MessagingException;
 import javax.mail.PasswordAuthentication;
 import javax.mail.Session;
 import javax.mail.Transport;
 import javax.mail.internet.InternetAddress;
 import javax.mail.internet.MimeBodyPart;
 import javax.mail.internet.MimeMessage;
 import javax.mail.internet.MimeMultipart;
 import org.apache.log4j.Logger;
 
 public class SendEmail
 {
   private static Logger log = Logger.getLogger("LogFileMonitor");
   static ReadPropertyBean rpb = new ReadPropertyBean();
   public static String SMTP_HOST_NAME = ReadPropertyBean.getMailServer();
   public static String SMTP_AUTH_USER = ReadPropertyBean.getMailUser();
   public static String SMTP_AUTH_PWD = ReadPropertyBean.getMailPass();
   public static String body;
 
   public void postMail(String subject, String message)
     throws MessagingException
   {
     try
     {
       boolean debug = false;
 
       System.out.println("The SMTP Server IP Address is :" + ReadPropertyBean.getMailServer());
       log.info("The SMTP Server IP Address is :" + ReadPropertyBean.getMailServer());
       System.out.println("The SMTP User Name is:" + ReadPropertyBean.getMailUser());
       log.info("The SMTP User Name is:" + ReadPropertyBean.getMailUser());
       System.out.println("The SMTP Password is :" + ReadPropertyBean.getMailPass());
       log.info("The SMTP Password is :" + ReadPropertyBean.getMailPass());
       Properties props = new Properties();
       props.put("mail.smtp.host", ReadPropertyBean.getMailServer());
 
       Authenticator auth = new SMTPAuthenticator();
       Session session = Session.getDefaultInstance(props, auth);
       session.setDebug(debug);
       System.out.println("The sessiong debugging is in " + debug + " Mode");
 
       Message msg = new MimeMessage(session);
 
       InternetAddress addressFrom = new InternetAddress(ReadPropertyBean.getFromEmailid());
       msg.setFrom(addressFrom);
 
       InternetAddress[] Toaddress = InternetAddress.parse(ReadPropertyBean.getToEmailIDs(), true);
       InternetAddress[] CCaddress = InternetAddress.parse(ReadPropertyBean.getCCEmailIDs(), true);
 
       msg.setRecipients(Message.RecipientType.TO, Toaddress);
       msg.setRecipients(Message.RecipientType.CC, CCaddress);
 
       MimeBodyPart textPart = new MimeBodyPart();
       textPart.setHeader("Content-Type", "text/plain; charset=\"utf-8\"");
       textPart.setContent(message, "text/html; charset=utf-8");
 
       msg.setSubject(subject);
       msg.setSentDate(new Date());
 
       MimeMultipart multipart = new MimeMultipart("mixed");
       multipart.addBodyPart(textPart);
 
       msg.setContent(multipart);
       Transport.send(msg);
 
       System.out.println("Mail have been shared To EmailIds >>>>  " + ReadPropertyBean.getToEmailIDs() + "  and CC Address >>>>  " + ReadPropertyBean.getCCEmailIDs());
       log.info("Mail have been shared To EmailIds >>>>  " + ReadPropertyBean.getToEmailIDs() + "  and CC Address >>>>  " + ReadPropertyBean.getCCEmailIDs());
     }
     catch (Exception e) {
       log.error("Caught Exception::" + e);
       System.out.println("Caught Exception::" + e);
     }
   }
 
   public class SMTPAuthenticator extends Authenticator {
     public SMTPAuthenticator() {
     }
 
     public PasswordAuthentication getPasswordAuthentication() {
       String username = SendEmail.SMTP_AUTH_USER;
       String password = SendEmail.SMTP_AUTH_PWD;
       return new PasswordAuthentication(username, password);
     }
   }
 }