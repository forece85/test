 package com.genpact.savvion.log;
 
 import java.io.IOException;
 import java.net.ServerSocket;
 
 public class CheckDaemonInstance
 {
   boolean isSuccess = false;
   private ServerSocket serverSocket;
 
   public CheckDaemonInstance(int port)
   {
     connectToServer(port);
   }
 
   public boolean isRunning() {
     return this.isSuccess;
   }
 
   public void connectToServer(int port) {
     try {
       this.serverSocket = new ServerSocket(port);
       if ((this.serverSocket != null) && (!this.serverSocket.isClosed()))
         this.isSuccess = true;
     }
     catch (IOException e) {
       e.printStackTrace();
     }
   }
 
   public void closeSocket() {
     try {
       if ((this.serverSocket != null) && (!this.serverSocket.isClosed()))
         this.serverSocket.close();
     }
     catch (Exception e) {
       e.printStackTrace();
     }
   }
 }