 package com.genpact.savvion.log;
 
 import java.io.File;
import java.io.IOException;
 import java.text.SimpleDateFormat;
 import java.util.ArrayList;
 import java.util.Date;
 import java.util.List;

 import org.apache.commons.io.input.ReversedLinesFileReader;
import org.apache.log4j.Logger;
 
 public class Entry
 {
	public static void main(String[] args) throws IOException
   {
     Logger log = Logger.getLogger("LogFileMonitor");
     ReversedLinesFileReader obj = null;
     try
     {
       LoadConfigParams lcp = new LoadConfigParams();
       lcp.ReadProps();
       CheckDaemonInstance instance = new CheckDaemonInstance(Integer.parseInt(ReadPropertyBean.getDaemonPort()));
       log.info("Daemon Running Port No: " + Integer.parseInt(ReadPropertyBean.getDaemonPort()));
       System.out.println("Daemon Running Port No: " + Integer.parseInt(ReadPropertyBean.getDaemonPort()));
       boolean isNotDeployed = instance.isRunning();
       if (isNotDeployed)
       {
         List<String> LogPath = new ArrayList<String>();
         LogPath = ReadPropertyBean.getFiles();
         List<String> LogNames = new ArrayList<String>();
         LogNames = ReadPropertyBean.getFileNames();
         List<String> fileFreq = new ArrayList<String>();
         fileFreq = ReadPropertyBean.getFileFrequency();
 		 List<String> ts = new ArrayList<String>();
         ts = ReadPropertyBean.getDateStamp();
         List<String> istr = new ArrayList<String>();
         istr = ReadPropertyBean.getindStr();
         List<String> iLst = new ArrayList<String>();
         iLst = ReadPropertyBean.getindLst();
         SendEmail smtp = new SendEmail();
         String strLL="";
         String strDate="";
         SimpleDateFormat sdf;
         SimpleDateFormat sdf1;
         Date date=null;
         for (int i = 0; i < ReadPropertyBean.getFiles().size(); i++) 
         {
        	 try
        	 {
        		 Date ModifiedFreq = new Date(System.currentTimeMillis() - Integer.parseInt((String)fileFreq.get(i)) * 60 * 1000);
        		 String lpath=((String)LogPath.get(i)).toString();
           		 String is=(String)istr.get(i);
           		 int indStr=Integer.parseInt(is);
				 String ie=(String)iLst.get(i);
           		 int indEnd=Integer.parseInt(ie);
           		 String ds=((String)ts.get(i)).toString();
           		 ds=ds.replaceAll("\"","");
           		 ds=ds.replaceAll("\\[","");
           		 ds=ds.replaceAll("]","");
           		 strLL="";
           		 File f = new File(lpath);
           		 obj = new ReversedLinesFileReader(f);
           		 strLL = obj.readLine();
			
           		 while((strLL==null)||(strLL.isEmpty())||(strLL.equals(""))||(!(Character.isDigit(strLL.charAt(0)))))
           		 {
					 strLL=obj.readLine();
           		 }
           		 System.out.println("Log Line: "+strLL);
           		 obj.close();
           		 System.out.println("Log closed successfully");
           		 log.info("Log closed successfully");
				
           		 strDate=strLL.substring(indStr,indEnd);
           		 strDate=strDate.replaceAll("\"","");
           		 strDate=strDate.replaceAll("\\[","");
           		 strDate=strDate.replaceAll("]","");
           		 sdf1= new SimpleDateFormat(ds);
           		 Date date1=sdf1.parse(strDate);
           		 sdf=new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
           		 String strTime=sdf.format(date1);
           		 date=sdf.parse(strTime);
           		 System.out.println("Log DateStamp: "+date);				
           		 if ((f.lastModified() <= ModifiedFreq.getTime())&&(date.getTime()<=ModifiedFreq.getTime()))
           		 {
           			 System.out.println("File  " + f + " Log Last Line is : " + strLL);
           			 log.info("File  " + f + " Last Log Line is: "+strLL);
           			 System.out.println("File  " + f + " was not Updated Since Last " + (String)fileFreq.get(i) + " Minutes or More. Kindly check  ");
           			 log.info("Log: " + f + " was not Updated Since Last " + (String)fileFreq.get(i) + " Minutes or More. Kindly check ");
           			 String message = "<html><body><b style= 'color:Red';>This is an auto-generated mail. Do not reply to this mail.<br></b><br>Hello All,<br><br>The Log File Mentioned in Subject Line was not Updated for the past " + 
           			 (String)fileFreq.get(i) + " Minutes or More mentioned in Property File. Kindly check the Logs and Location.<br>" + "<br><br><b style= 'color:Blue';>Log Path is:<br></b>"+ (String)LogPath.get(i) + "<br><br><b style= 'color:Green';>Last Line of Log is:<br></b>"+ strLL +
           			 "<br><br>Thanks & Regards<br>Savvion Support Team<br>E:" + ReadPropertyBean.getFromEmailid()+ "</body></html>";
           			 smtp.postMail("Log:  " + (String)LogNames.get(i) + " was not Updated Since Last " + (String)fileFreq.get(i) + " Minutes or More", message);
			   }
           else
           {
             System.out.println((String)LogNames.get(i) + "  Modified at >>>>> " + new Date(f.lastModified()));
             System.out.println((String)LogNames.get(i) + "  Last Modified from Log  >>>>> " + date);
             log.info((String)LogNames.get(i) + "  Modified at >>>>> " + new Date(f.lastModified())+"  ||  Log Date >>>>> "+ date);
           }
         }catch(Exception e)
         {
      	   	System.out.println("Exception occured while reading logger no: "+(i+1)+":"+(String)LogNames.get(i));
      	   	log.info("Error :" + "Exception occured while reading logger : "+(i+1)+":"+(String)LogNames.get(i));
         }finally
         {
        	 System.out.println("At Finally...");
        	 log.info("At Finally...");
        	 if(obj != null)
        	 {
        		 obj.close();
        		 System.out.println("Log closed successfully at Finally...");
        		 log.info("Log closed successfully at Finally...");
        	 }
         }
       }
         System.out.println("*****************************************************************");
         log.info("Exiting from Dameon .....................");
         System.exit(1);
       }
       else 
       {
         System.out.println();
         System.out.println();
         System.out.println();
         System.out.println("-------------------------W A R N I N G--------------------------");
         System.out.println();
         System.out.println();
         System.out.println();
         System.out.println("*****************************************************************");
         System.out.println("*                                                               *");
         System.out.println("*   D A E M O N    IS      A L R E A D Y    R U N N I N G       *");
         System.out.println("*                                                               *");
         System.out.println("*****************************************************************");
         log.info("*   D A E M O N    IS      A L R E A D Y    R U N N I N G       *");
         System.exit(1);
       }
     }
     catch (Exception ex)
     {
       ex.printStackTrace();
       log.info("Error :" + ex.toString(), ex);
       log.info("info :" + "*****************************************************************");
     }finally
     {
    	 System.out.println("At Finally...");
    	 log.info("At Finally...");
    	 if(obj != null)
    	 {
    		 obj.close();
    		 System.out.println("Log closed successfully at Finally...");
    		 log.info("Log closed successfully at Finally...");
    	 }
     }
   }
 }