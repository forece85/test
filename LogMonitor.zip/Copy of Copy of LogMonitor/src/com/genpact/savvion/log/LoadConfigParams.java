 package com.genpact.savvion.log;
 
 import java.io.FileInputStream;
 import java.util.ArrayList;
 import java.util.Properties;
 
 public class LoadConfigParams
 {
   ReadPropertyBean rpd = new ReadPropertyBean();
 
   @SuppressWarnings({ "rawtypes", "unchecked" })
		public ReadPropertyBean ReadProps() throws Exception { 
	   Properties prop = new Properties();
     ArrayList files = new ArrayList();
     ArrayList fileName = new ArrayList();
     ArrayList fileFrequency = new ArrayList();
		 ArrayList DateStamp = new ArrayList();
		 ArrayList indStr = new ArrayList();
		 ArrayList indLst = new ArrayList();
		 
     prop.load(new FileInputStream("..\\conf\\FileMonitring.properties"));
     System.out.println("Configuration is about to Load");
     ReadPropertyBean.setDaemonPort(prop.getProperty("daemon.running.port"));
 
     ReadPropertyBean.setSleepTime(prop.getProperty("daemon.SleepTime"));
 
     ReadPropertyBean.setAppCode(prop.getProperty("APP_CODE"));
 
     ReadPropertyBean.setFileMonitor(prop.getProperty("File.Monitor.count"));
 
     ReadPropertyBean.setMailServer(prop.getProperty("mail.server.ip"));
 
     ReadPropertyBean.setMailUser(prop.getProperty("mail.server.user"));
 
     ReadPropertyBean.setMailPass(prop.getProperty("mail.server.pass"));
 
     ReadPropertyBean.setToEmailIDs(prop.getProperty("receipent.ToEmailids"));
 
     ReadPropertyBean.setCCEmailIDs(prop.getProperty("receipent.CCEmailids"));
 
     ReadPropertyBean.setFromEmailid(prop.getProperty("from.Emailid"));
 
     for (int j = 1; j <= Integer.parseInt(ReadPropertyBean.getFileMonitor()); j++) {
       files.add(prop.getProperty(ReadPropertyBean.getAppCode() + "." + j + ".file"));
     }
     ReadPropertyBean.setFiles(files);
 
     for (int j = 1; j <= Integer.parseInt(ReadPropertyBean.getFileMonitor()); j++) {
       fileName.add(prop.getProperty(ReadPropertyBean.getAppCode() + "." + j + ".fileName"));
     }
     ReadPropertyBean.setFileNames(fileName);
 
     for (int j = 1; j <= Integer.parseInt(ReadPropertyBean.getFileMonitor()); j++) {
       fileFrequency.add(prop.getProperty(ReadPropertyBean.getAppCode() + "." + j + ".fileFrequency"));
     }
     ReadPropertyBean.setFileFrequency(fileFrequency);
		
     for (int j = 1; j <= Integer.parseInt(ReadPropertyBean.getFileMonitor()); j++) {
		    DateStamp.add(prop.getProperty(ReadPropertyBean.getAppCode() + "." + j + ".DateStamp"));
		  }
		  ReadPropertyBean.setDateStamp(DateStamp);
		  
	 for (int j = 1; j <= Integer.parseInt(ReadPropertyBean.getFileMonitor()); j++) {
			    indStr.add(prop.getProperty(ReadPropertyBean.getAppCode() + "." + j + ".indStr"));
			  }
			  ReadPropertyBean.setindStr(indStr);
			  
	 for (int j = 1; j <= Integer.parseInt(ReadPropertyBean.getFileMonitor()); j++) {
				    indLst.add(prop.getProperty(ReadPropertyBean.getAppCode() + "." + j + ".indLst"));
				  }
				  ReadPropertyBean.setindLst(indLst);
 
     System.out.println("Configuration is Done");
     return this.rpd;
   }
 }